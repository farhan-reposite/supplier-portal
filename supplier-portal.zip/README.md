# Supplier Portal (Cloudflare Worker + D1)

Admin imports the monthly PO Excel files, records what was received, and suppliers print their own box labels (80 mm, POS-80).

```
public/            pages the browser loads
  logo.png         <- PUT YOUR LOGO HERE (see "Logo")
  po_template.xlsx the import template
  vendor/          jsPDF, QR generator, SheetJS (bundled, no CDN)
src/index.js       the Worker (API + login), talks to D1
schema.sql         tables for a NEW database
migrations/        changes for a database you already have
.vscode/tasks.json one-key deploy from VS Code
```

## Logo

Save your logo as **`public/logo.png`** (that exact name).

- Shape: wide, about 1 : 4 (for example 800 × 200 px). A transparent PNG works best.
- It shows in the top bar at 34 px high and on the login page at 48 px high.
- Until the file exists, the portal shows the text "Supplier Portal" instead.
- Want SVG? Save it as `logo.svg` and change `/logo.png` to `/logo.svg` in `public/common.js` and `public/index.html`.
- After adding or changing it, deploy again.

## Update an existing deployment (you already have the portal running)

1. **Keep your database id.** Copy the new files over your old folder, but keep your own `wrangler.jsonc`. If it was replaced, paste your `database_id` back in (find it with `npx wrangler d1 list`).
2. **Run `npm install`** (only needed once if packages changed).
3. **Run the database migration once:**
   ```
   npm run migrate:001
   ```
   This adds the new columns and removes accidental duplicate lines. Run it only once; a second run says the column already exists.
4. **Deploy** (next section).

New install instead? Follow "First-time setup" at the bottom.

## Deploy from VS Code

1. **File → Open Folder…** and choose the project folder.
2. Open the terminal: **Terminal → New Terminal** (or <kbd>Ctrl</kbd>+<kbd>`</kbd>). It opens inside the project.
3. Log in to Cloudflare once: `npx wrangler login` (a browser tab opens, press Allow).
4. Deploy:
   - **Fastest:** press <kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>B</kbd> (runs "Deploy to Cloudflare"), or
   - type `npm run deploy` in the terminal.
5. It prints your URL. Refresh the portal with <kbd>Ctrl</kbd>+<kbd>F5</kbd> to skip the browser cache.

Other tasks (**Terminal → Run Task…**): **Run locally** (test at http://localhost:8787 without touching the live site), **Live logs** (shows errors from the live Worker).

Every change you make to a file only goes live after you deploy again. Your data in D1 is never touched by a deploy.

## Importing the monthly PO files

Add your suppliers first (**Suppliers → Add supplier**). Then open **Import**, drop one or many `.xlsx` files, check the preview, press **Import**. Each file is one supplier, one month, one PO.

| What | Where |
|---|---|
| Supplier code | first word of the **file name** (`KW_po.xlsx` is supplier `KW`). It must already exist under **Suppliers** |
| PO number | cell **F8** (the leading `:` is removed) |
| Month | cell **I15** (first date of the month) |
| Part number | column **D**, from row 17 |
| Part name | column **G** |
| Quantity per box | column **H** |
| Daily quantity | column **I** = day 1, **J** = day 2, and so on |

- Boxes = daily quantity ÷ quantity per box, rounded up. If it does not divide evenly, the last box carries the remainder (for example 714 pcs at 20 per box is 35 boxes of 20 and one of 14).
- Empty or 0 means no delivery. Parts with no delivery all month are skipped.
- Cell F9 (a second PO) is ignored. Import a second file if the second PO needs its own schedule.
- **Files for a supplier code that is not registered are refused**, in the preview and again on the server. Nothing is created from a file. Fix the file name or add the supplier, then drop the file again.
- Two files with the same supplier, month and PO in one drop: only the first is accepted.
- Importing the same supplier, month and PO again **updates** it: lines already marked received or short are kept and re-checked against the new quantity; lines no longer in the file are removed.
- **Download template** gives a file in this layout, named with the supplier you pick (it only lists registered suppliers).

## Daily use

**Admin → Schedule & receiving** (opens first)
- Pick a month. Supplier badges show who has data that month; a dot means shortage (amber) or overdue (red).
- The table is the Excel layout: parts down, days across. Click a quantity, or a day number, to open the receiving panel.
- In the panel type the received quantity (or press **Full**), then **Save changes**. Below the scheduled quantity becomes a shortage the supplier sees. The arrows move between delivery dates.
- Filters: search, All / Not received / Shortage. **Export Excel** saves the view with scheduled and received sheets.
- Keys: <kbd>/</kbd> search, <kbd>[</kbd> <kbd>]</kbd> previous / next month, <kbd>Esc</kbd> close the panel.

**Supplier page**
- Pick one or more dates in the calendar. Each date has its own No SJ field.
- Untick parts, or set a box range, to print only some labels (for example to replace one damaged label).
- **Print labels** opens the print window with one 80 × 80 mm label per page. Choose the POS-80 printer and print. Margins stay on *None* and scale on *100%*.
- **Download PDF** gives the same labels as a file.
- For one-click printing with no print window: make the POS-80 the Windows default printer and start Chrome with `--kiosk-printing`.

**Admin → Downloads** shows who downloaded or printed labels, and which deliveries in the next 7 days have none yet.

## Label settings

All in `public/labels.js`, at the top: `trailer` (text added after the supplier code in the full QR; empty now), `emptyField`, `sjFallback` ("Road Number"), `qcText`.

Full QR: `date;sj;partNo; ;qty;po;;;box/boxes;supplierCode`. Top-left QR: part number only.

## First-time setup (new database)

```
npm install
npx wrangler login
npx wrangler d1 create supplier-portal-db        # paste the database_id into wrangler.jsonc
npm run db:remote                                 # creates the tables
node scripts/make-admin.mjs admin "your-strong-password"
npx wrangler d1 execute supplier-portal-db --remote --file=seed-admin.sql
```
Delete `seed-admin.sql` afterwards, then deploy.

## Good habits

- **Backup:** `npm run backup` saves the database to `backup.sql`.
- **Rate limit logins:** in the Cloudflare dashboard add a rate-limiting rule for `/api/login` (needs the Worker on your own domain).
- **Keep a copy of this folder** somewhere safe.

## Known limits

- The supplier calendar lists every month that has data. Printing more than 2500 labels in one go is blocked; print fewer dates at a time.
- Money owed and paid is not included. Only quantity shortage is.
- "Today" on the server uses Western Indonesia Time (UTC+7). Change `TZ_HOURS` in `src/index.js` if needed.
